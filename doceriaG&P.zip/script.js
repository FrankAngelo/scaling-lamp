const botaoEnviar = document.getElementById("enviar")

botaoEnviar.addEventListener('click', function() {
    alert("Mensagem enviada com sucesso!")
});